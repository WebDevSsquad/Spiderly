package com.Spiderly.JavaServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
